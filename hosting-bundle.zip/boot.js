"use strict";document.documentElement.setAttribute("data-js","");
